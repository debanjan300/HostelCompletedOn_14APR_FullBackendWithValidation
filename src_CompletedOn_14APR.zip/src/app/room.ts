export class Room {
    roomId:number=0;
    roomType:string="";
    roomOccupancy:number=0;
    roomCapacity:number=0;
    fee:number=0;
    bookingStatus:string="";


    // Long roomId;
	// String roomType;
	// Integer roomOccupancy;
	// Integer fee;
	// String bookingStatus;
}
