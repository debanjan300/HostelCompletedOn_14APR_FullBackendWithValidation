package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Allotment;
import com.example.demo.entity.Invoice;
import com.example.demo.service.InvoiceService;

@RestController
@RequestMapping("/invoice")
@CrossOrigin(origins = {"http://localhost:4200", "*"})
public class InvoiceController {
	@Autowired
    InvoiceService is;
	
	@GetMapping("/")
    public List<Invoice> getAllInvoices()
    {
        //display all invoices
        List<Invoice> invoices = is.read();
        return invoices;
    }
	 @GetMapping("/{invoiceId}")            
	    public Invoice findInvoiceById(@PathVariable("invoiceId") Long invoiceId)
	    {
	        return is.read(invoiceId);
	    }
	 @PostMapping("/")
	    public Invoice addInvoice(@RequestBody Invoice invoice)
	    {
	        return is.create(invoice);
	    }
	 @PutMapping("/")
	    public Invoice modifyInvoice(@RequestBody Invoice invoice)
	    {
	        return is.update(invoice);
	    }
	 @DeleteMapping("/{invoiceId}")
	    public void deleteInvoice(@PathVariable("invoiceId") Long invoiceId)
	    {
	        is.delete(invoiceId);
	    }
	 @GetMapping("/findInvoiceByAllotmentId/{allotmentId}")
	 public Invoice findInvoiceByAllotmentId(@PathVariable("allotmentId") Long allotmentId)
	 {
		 return is.findInvoiceByAllotmentId(allotmentId);
	 }
	
}
