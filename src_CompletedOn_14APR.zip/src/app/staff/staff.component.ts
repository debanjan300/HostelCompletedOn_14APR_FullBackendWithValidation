import { Component, DoCheck, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Staff } from '../staff';
import { StaffService } from '../staff.service';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-staff',
  templateUrl: './staff.component.html',
  styleUrls: ['./staff.component.css']
})
export class StaffComponent implements OnInit, DoCheck {

  staffForm:any;
  staffs;
  loggedRole:string|null="";

  constructor(private fb:FormBuilder, private bs:StaffService,private router:Router,private us:UserService) { 
    this.staffForm=this.fb.group({
      staffId:[''],
      userName:[''],
      dateOfJoining:[''],
      designation:['DBA'],
      salary:['']
    });
  }
  ngDoCheck(): void {
    var loggedUserName=localStorage.getItem("loggedUserName");
    this.loggedRole=localStorage.getItem("loggedRole");
    
    if(loggedUserName==null)
    {
      alert("You have not logged in. Click OK to Login")
    this.router.navigateByUrl('/(col3:Login)');
    }
    else{
      if(this.loggedRole!="Admin"){
        alert("You are an "+this.loggedRole+". Click OK to continue.");
        this.router.navigateByUrl('/(col3:home)');
      }
      else{
        
   // this.getAllStaffs();
        }
    }
  }

  ngOnInit(): void {
    this.getAllStaffs();
  }
  getAllStaffs()
  {
    this.bs.getAllStaffs().subscribe((data)=>{
      this.staffs=data;
    })
  }
  fnSelect(staffId)
  {
    var staff=new Staff();
  
    this.bs.findStaffById(staffId).subscribe((data)=>{
      console.log(data);
      staff=<Staff><any>data;
      this.staffForm.controls.userName.patchValue(staff.user.userName);
      this.staffForm.patchValue(data);
    });
  }
  fnFind()
  {
    var staffId=this.staffForm.controls.staffId.value;
    this.fnSelect(staffId);
  }
  fnAdd()
  {
    var staff=this.staffForm.value;
    var userName=this.staffForm.controls.userName.value;
    var user=new User();
    this.us.findUserByUserName(userName).subscribe((data)=>{
      user=<User><any>data;
      staff.user=user;
      this.bs.addStaff(staff).subscribe((data)=>{
        this.getAllStaffs();
      });
    });
  }
  fnModify()
  {
    var staff=this.staffForm.value;
    var userName=this.staffForm.controls.userName.value;
    var user=new User();
    this.us.findUserByUserName(userName).subscribe((data)=>{
      user=<User><any>data;
      staff.user=user;
      this.bs.modifyStaff(staff).subscribe((data)=>{
        this.getAllStaffs();
      });
    });
  }
  fnDelete()
  {
    var staffId=this.staffForm.controls.staffId.value;
    this.bs.deleteStaff(staffId).subscribe((data)=>{
      console.log(data);
      this.getAllStaffs();
    })
  }

}
