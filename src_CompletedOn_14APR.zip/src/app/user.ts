export class User {
    userName:string="";
    password:string="";
    firstName:string="";
    lastName:string="";
    dateOfBirth:Date=new Date();
    emailAddress:string="";
    role:string="";
    status:string="";


}


    // private String userName;
	// private String password;
	// private String firstName;
	// private String lastName;
	// private Date dateOfBirth;
	// private String emailAddress;
	// private String role;
	// private String status;