package com.example.demo.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Invoice")
public class Invoice {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long invoiceId;
	@OneToOne
	private Allotment allotment;
	private Date invoiceDate;
	public Invoice() {}
	public Invoice(Long invoiceId, Allotment allotment, Date invoiceDate) {
		super();
		this.invoiceId = invoiceId;
		this.allotment = allotment;
		this.invoiceDate = invoiceDate;
	}
	public Long getInvoiceId() {
		return invoiceId;
	}
	public void setInvoiceId(Long invoiceId) {
		this.invoiceId = invoiceId;
	}
	public Allotment getAllotment() {
		return allotment;
	}
	public void setAllotment(Allotment allotment) {
		this.allotment = allotment;
	}
	public Date getInvoiceDate() {
		return invoiceDate;
	}
	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}
	@Override
	public String toString() {
		return "Invoice [invoiceId=" + invoiceId + ", allotment=" + allotment + ", invoiceDate=" + invoiceDate + "]";
	}
	

}
