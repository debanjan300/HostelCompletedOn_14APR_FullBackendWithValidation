package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.entity.Student;
import com.example.demo.entity.User;
import com.example.demo.model.StudentRepository;


@Component("ss")
public class StudentService {
	@Autowired 
    private StudentRepository sRepo;
    
    public Student create(Student student)
    {
        return sRepo.save(student);
    }
    public List<Student> read()
    {
        return sRepo.findAll();
    }
    public Student read(Long studentId)
    {
        return sRepo.findById(studentId).get();
    }
    public Student read(String user_username)
    {
        return sRepo.findStudentByUserName(user_username);
    }
    public Student update(Student student)
    {
        return sRepo.save(student);
    }
    public void delete(Long studentId)
    {
       sRepo.delete(read(studentId));
    }
    
    public User findUserByStudentId(Long studentId)
    {
    	return sRepo.findUserByStudentId(studentId);
    }
}
