import { Component, DoCheck, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit,DoCheck
{
  ngDoCheck(): void {
    this.loggedFirstName=localStorage.getItem("loggedFirstName");
    this.loggedRole=localStorage.getItem("loggedRole");
  }
  loggedFirstName:string|null="";
  loggedRole:string|null="";
  date:Date=new Date();
  
  ngOnInit(): void {
   
  }
  title = 'routing-demo';


  
}
