import { Component, DoCheck, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit, DoCheck {
  users;
  loggedRole:string|null="";
  constructor(private us:UserService, private router:Router) { }
  ngDoCheck(): void {
    var loggedUserName=localStorage.getItem("loggedUserName");
    this.loggedRole=localStorage.getItem("loggedRole");
    
    if(loggedUserName==null)
    {
      alert("You have not logged in. Click OK to Login")
    this.router.navigateByUrl('/(col3:Login)');
    }
    else{
      if(this.loggedRole!="Admin"){
        alert("You are an "+this.loggedRole+". Click OK to continue.");
        this.router.navigateByUrl('/(col3:home)');
      }
      else{
        
   // this.getAllStaffs();
        }
    }
  }

  ngOnInit(): void {
    this.getAllUsers();
  }

  getAllUsers()
  {
    this.us.getAllUser().subscribe((data)=>{
      this.users=data;
    })
  }

}
