package com.example.demo.model;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.entity.Allotment;

@Repository
public interface AllotmentRepository extends JpaRepository<Allotment, Long>{
//	@Transactional
//	@Modifying
//	@Query("update Room r set r.roomOccupancy=r.roomOccupancy-1 where r.roomId=roomId")
//	public int decreaseOccupancy(@Param("roomId") Long roomId);
//	@Query("update Room r set r.bookingStatus='Booked' where r.roomOccupancy=0")
//	public int booked(@Param("roomOccupancy") Integer roomOccupancy);
	@Transactional
	@Modifying
	@Query("update Allotment a set a.status='Approved' where a.allotmentId=:allotmentId")
	public int statusUpdate(@Param("allotmentId") Long allotmentId);
	@Transactional
	@Modifying
	@Query("update Allotment a set a.status='Rejected' where a.allotmentId=:allotmentId")
	public int statusUpdate2(@Param("allotmentId") Long allotmentId);
	
	@Transactional
	@Modifying
	@Query("update Allotment a set a.status=:status where a.allotmentId=:allotmentId")
	public int updateStatus(@Param("status") String status, @Param("allotmentId") Long allotmentId);
	
	 @Query("select a from Allotment a where a.student.studentId=:studentId")
	 public List<Allotment> findAllotmentByStudentId(@Param("studentId") Long studentId);
	 
	 @Query("select a from Allotment a where a.student.studentId=:studentId and a in (select i.allotment from Invoice i)")
		List<Allotment> findPaidAllotmentsByStudentId(@Param("studentId") Long studentId);
	 @Query("select a from Allotment a where a.student.studentId=:studentId and a not in (select i.allotment from Invoice i)")
		List<Allotment> findUnPaidAllotmentsByStudentId(@Param("studentId") Long studentId);
	 
	 @Query("select  count(s) from Student s where (s.studentId not in (select a.student.studentId from Allotment a where a.student.studentId=:studentId) or s.studentId in(select a.student.studentId from Allotment a where a.student.studentId=:studentId and a.status not in ('Pending','Approved'))) and s.studentId=:studentId")
	 	int	findAllotmentForStatusNotApproved(@Param("studentId") Long studentId);
	
	


}
