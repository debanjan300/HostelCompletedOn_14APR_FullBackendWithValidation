package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.entity.Staff;
import com.example.demo.model.StaffRepository;

@Component("staffservice")
public class StaffService {
	@Autowired
    private StaffRepository staffRepository;
    public Staff create(Staff staff) {
        return staffRepository.save(staff);
    }
    public List<Staff> read() {
        return staffRepository.findAll();
    }
    
    public Staff read(Long staffId) 
    {
        return staffRepository.findById(staffId).get();
    }
    public Staff update(Staff staff) {
        return staffRepository.save(staff);
    }
    public void delete(Long staffId) {
        Staff staff = staffRepository.findById(staffId).get();
        staffRepository.delete(staff);
    }

}
