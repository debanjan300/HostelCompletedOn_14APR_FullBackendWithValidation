package com.example.demo.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="STUDENT")
public class Student {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Long studentId;
	@OneToOne
	private User user;
	private String guardianFirstName;
	private String guardianLastName;
	private String guardianMobile;
	
	public Student() {
		
	}

	public Student(Long studentId, User user, String guardianFirstName, String guardianLastName,
			String guardianMobile) {
		super();
		this.studentId = studentId;
		this.user = user;
		this.guardianFirstName = guardianFirstName;
		this.guardianLastName = guardianLastName;
		this.guardianMobile = guardianMobile;
	}

	public Long getStudentId() {
		return studentId;
	}

	public void setStudentId(Long studentId) {
		this.studentId = studentId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getGuardianFirstName() {
		return guardianFirstName;
	}

	public void setGuardianFirstName(String guardianFirstName) {
		this.guardianFirstName = guardianFirstName;
	}

	public String getGuardianLastName() {
		return guardianLastName;
	}

	public void setGuardianLastName(String guardianLastName) {
		this.guardianLastName = guardianLastName;
	}

	public String getGuardianMobile() {
		return guardianMobile;
	}

	public void setGuardianMobile(String guardianMobile) {
		this.guardianMobile = guardianMobile;
	}

	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", user=" + user + ", guardianFirstName=" + guardianFirstName
				+ ", guardianLastName=" + guardianLastName + ", guardianMobile=" + guardianMobile + "]";
	}
}
