
import { Component, DoCheck, EventEmitter, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit, DoCheck {

  constructor(private router:Router) { }
  ngDoCheck(): void {
    console.log("Logout component ngDocheck...")
    localStorage.removeItem("loggedRole");
    localStorage.removeItem("loggedUserName");
  }

  ngOnInit(): void {
    this.router.navigate(['../menu']);
 
  }

}
