import { JsonpClientBackend } from '@angular/common/http';
import { Component, DoCheck, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Allotment } from '../allotment';
import { AllotmentService } from '../allotment.service';
import { Room } from '../room';
import { RoomService } from '../room.service';
import { Student } from '../student';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-room',
  templateUrl: './room.component.html',
  styleUrls: ['./room.component.css']
})
export class RoomComponent implements OnInit, DoCheck {
  st:any;
  room: Room = new Room();
  student: Student | any = null;
  role: string = "";
  roomForm: any;
  rooms: any;
  noOfBooking:any;
  constructor(private fb: FormBuilder, private rs: RoomService, private router: Router, private as: AllotmentService, private ss: StudentService) {
    this.roomForm = this.fb.group({
      roomId: [''],
      roomType: [''],
      roomOccupancy: [''],
      roomCapacity:[''],
      fee: [''],
      bookingStatus: ['Available']
    });
  }
  fnBlockUser() {
    var userName: string | any = localStorage.getItem('loggedUserName');
    this.ss.findStudentByUserName(userName).subscribe((data) => {
      console.log("Romm component DoCheck DATA: " + JSON.stringify(data));

      this.student = data;
    });
  }
  fnBlockToBookRoom()
  {
    var userName: string | any = localStorage.getItem('loggedUserName');
    this.ss.findStudentByUserName(userName).subscribe((data) => {
      //console.log("Romm component DoCheck DATA: " + JSON.stringify(data));
      //console.log("fnBlockToBookRoom says:"+JSON.stringify(data));
      this.student=<Student><any>data;
    this.as.findAllotmentForStatusNotApproved(this.student.studentId).subscribe((data)=>{
      console.log(" fnBlockToBookRoom() returns "+data);
      this.noOfBooking=<number>data;
      console.log("No of booking is "+this.noOfBooking);
    });
    });

     
  }
  ngDoCheck(): void {
    var strRole = localStorage.getItem("loggedRole");
    if (strRole != null)
      this.role = strRole;
    else
      this.role = "";
    console.log("Room component do check method:" + this.role);
    // this.fnBlockToBookRoom();
  }

  ngOnInit(): void {
    this.fnBlockUser();
    this.fnBlockToBookRoom();

    var loggedUserName = localStorage.getItem("loggedUserName");
    if (loggedUserName == null) {
      alert("You have not logged in. Click OK to log in.");
      this.router.navigateByUrl('/(col3:Login)');
    }
    else
      this.router.navigateByUrl('/(col2:room)');
    this.loadRooms();
  }

  loadRooms() {
    this.rs.getAllRooms().subscribe((data) => {
      console.log(data);
      this.rooms = data;

    });
  }
  fnAdd() {
    var room = this.roomForm.value;
    this.rs.addRoom(room).subscribe((data) => {
      console.log(data);
      this.loadRooms();
    });
  }
  fnModify() {
    var room = this.roomForm.value;
    this.rs.modifyRoom(room).subscribe((data) => {
      console.log(data);
      this.loadRooms();
    });
  }
  fnDelete() {
    var roomId = this.roomForm.controls.roomId.value;
    // alert(roomId);
    this.rs.deleteRoom(roomId).subscribe((data) => {
      console.log(data);
      this.loadRooms();
    });
  }
  fnBook(rid: string) {

    var allotment = new Allotment();
    //fill the details in the allotment object

    var room: Room = new Room();
    var student: Student = new Student();
    //find room by roomId                   http://localhost:8080/room/1011
    this.rs.findRoomById(rid).subscribe((data) => {
      console.log("Room component, fnBook, found room by id:" + rid + " is : " + JSON.stringify(data));
      room = <any>data;
    
      
      allotment.room = room;
      allotment.allocationDate = new Date();
      //find the student object by userName;    http://localhost:8080/student/findByUserName/d001
      var userName: string | any = localStorage.getItem('loggedUserName');
      this.ss.findStudentByUserName(userName).subscribe((data) => {
        console.log('Room component fnBook method, received student object is ' + JSON.stringify(data));
        var student: Student = <any>data;
        allotment.student = student;
        //add the allotment to the db
        allotment.status = "Pending";
        this.as.addAllotment(allotment).subscribe((data) => {
          console.log("Response after adding allotment is :" + JSON.stringify(data));
          this.router.navigateByUrl('/(col2:invoice)');
        })
      });

    });
  }

}
