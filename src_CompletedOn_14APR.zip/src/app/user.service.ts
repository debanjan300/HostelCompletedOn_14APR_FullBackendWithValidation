import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  url:string='http://localhost:8080/user/';
  url2:string='http://localhost:8080/getAllUserName';
  constructor(private http:HttpClient) { }


  // user/{userName}
  getAllUser()
  {
    return this.http.get(this.url);
  }
  getAllUserName()
  {
    return this.http.get(this.url2);
  }
  findUserByUserName(userName:string)
  {
    return this.http.get(this.url+userName);
  }
  addUser(user:any)
  {
    return this.http.post(this.url,user);
  }

  modifyUser(user:any)
  {
    return this.http.put(this.url,user);
  }
  removeUser(userName:string)
  {
    return this.http.delete(this.url+userName);
  }
  validateLogin(formData:any):Observable<any>
  {
    console.log(formData)
    return this.http.post(this.url+"login",formData);
  }

  generateOtp(emailAddress:string)
  {
    return this.http.post(this.url+"otp",emailAddress);
  }

  //manually create observable
  // and publish some data using next()
  method1() 
  {
    const myObservable=new Observable(observer=>{
      setTimeout(()=>{
        observer.next([10,30,40,100,120]);
      },3000);
    });
    return myObservable;
  }
  method2()
  {
    const myObservable=new Observable(observer=>{
      setTimeout(()=>{
        observer.next([10,30,40,100,120]);
      },3000);
      setTimeout(()=>{
        observer.next([10,30,40,100,120,200]);
      },3000);
    });
    return myObservable;
  }

}
