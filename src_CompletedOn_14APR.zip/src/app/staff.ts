import { User } from "./user";

export class Staff {

    staffId:number=0;
    user:User=new User();
    dateOfJoining:Date=new Date();
    designation:string="";
    salary:number=0.0;


    // private Long staffId;
    // @OneToOne
    // private User user;
    // private Date dateOfJoining;
    // private String designation;
    // private Float salary;
}
